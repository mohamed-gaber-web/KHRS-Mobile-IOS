(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["choose-language-choose-language-module"],{

/***/ "06s9":
/*!*******************************************************************!*\
  !*** ./src/app/choose-language/choose-language-routing.module.ts ***!
  \*******************************************************************/
/*! exports provided: ChooseLanguagePageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ChooseLanguagePageRoutingModule", function() { return ChooseLanguagePageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "8Y7J");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "iInd");
/* harmony import */ var _choose_language_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./choose-language.page */ "Waqm");




const routes = [
    {
        path: '',
        component: _choose_language_page__WEBPACK_IMPORTED_MODULE_3__["ChooseLanguagePage"]
    }
];
let ChooseLanguagePageRoutingModule = class ChooseLanguagePageRoutingModule {
};
ChooseLanguagePageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], ChooseLanguagePageRoutingModule);



/***/ }),

/***/ "Ivhk":
/*!***********************************************************!*\
  !*** ./src/app/choose-language/choose-language.module.ts ***!
  \***********************************************************/
/*! exports provided: ChooseLanguagePageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ChooseLanguagePageModule", function() { return ChooseLanguagePageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "8Y7J");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "SVse");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "s7LF");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "sZkV");
/* harmony import */ var _choose_language_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./choose-language-routing.module */ "06s9");
/* harmony import */ var _choose_language_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./choose-language.page */ "Waqm");







let ChooseLanguagePageModule = class ChooseLanguagePageModule {
};
ChooseLanguagePageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
            _choose_language_routing_module__WEBPACK_IMPORTED_MODULE_5__["ChooseLanguagePageRoutingModule"]
        ],
        declarations: [_choose_language_page__WEBPACK_IMPORTED_MODULE_6__["ChooseLanguagePage"]]
    })
], ChooseLanguagePageModule);



/***/ }),

/***/ "Waqm":
/*!*********************************************************!*\
  !*** ./src/app/choose-language/choose-language.page.ts ***!
  \*********************************************************/
/*! exports provided: ChooseLanguagePage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ChooseLanguagePage", function() { return ChooseLanguagePage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _raw_loader_choose_language_page_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! raw-loader!./choose-language.page.html */ "eLml");
/* harmony import */ var _choose_language_page_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./choose-language.page.scss */ "rqvV");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ "8Y7J");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "iInd");
/* harmony import */ var _shared_services_app_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../shared/services/app.service */ "BbT4");






let ChooseLanguagePage = class ChooseLanguagePage {
    constructor(router, appSerrvice) {
        this.router = router;
        this.appSerrvice = appSerrvice;
        this.isLoading = false;
        this.subs = [];
        this.isSelected = false;
        this.classname = false;
    }
    ngOnInit() {
        this.isLoading = true;
        this.subs.push(this.appSerrvice.getLanguage().subscribe(response => {
            this.isLoading = false;
            this.langItems = response['result'];
        }));
    }
    chooseLanguage() {
        this.router.navigate(['/intro']);
    }
    getLanguageId(id) {
        console.log(event);
        this.isSelected = !this.isSelected;
        localStorage.setItem('languageId', JSON.stringify(id));
    }
    ngOnDestroy() {
        this.subs.forEach((sub) => sub.unsubscribe());
    }
};
ChooseLanguagePage.ctorParameters = () => [
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_4__["Router"] },
    { type: _shared_services_app_service__WEBPACK_IMPORTED_MODULE_5__["AppService"] }
];
ChooseLanguagePage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
        selector: 'app-choose-language',
        template: _raw_loader_choose_language_page_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_choose_language_page_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
    })
], ChooseLanguagePage);



/***/ }),

/***/ "eLml":
/*!*************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/choose-language/choose-language.page.html ***!
  \*************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<div class=\"choose-language\">\r\n  <h1 class=\"title\"> Choose Language </h1>\r\n</div>\r\n\r\n\r\n<ion-content>\r\n\r\n  <ion-grid class=\"lang-bg\">\r\n\r\n    <ion-row>\r\n\r\n      <ion-spinner  *ngIf=\"isLoading\"></ion-spinner>\r\n      <ion-col (click)=\"getLanguageId(item.id)\" size-xs=\"4\" size-md=\"3\" *ngFor=\"let item of langItems\">\r\n        <ion-img  [src]=\"item.icon\" class=\"lang-img\"></ion-img>\r\n        <h3> <ion-text color=\"primary\"> {{ item.name }} </ion-text> </h3>\r\n      </ion-col>\r\n\r\n    </ion-row>\r\n\r\n  </ion-grid>\r\n  <div class=\"button-start\">\r\n\r\n    <ion-button [disabled]='isSelected === false' (click)=\"chooseLanguage()\">\r\n      <ion-img src=\"../../assets/images/logo-hand-2.png\"></ion-img>\r\n      START\r\n    </ion-button>\r\n  </div>\r\n\r\n\r\n</ion-content>\r\n");

/***/ }),

/***/ "rqvV":
/*!***********************************************************!*\
  !*** ./src/app/choose-language/choose-language.page.scss ***!
  \***********************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (".choose-language h1.title {\n  text-align: center;\n  color: var(--ion-color-second-app);\n  font-weight: 600 !important;\n  font-size: 25px;\n  margin: 70px 0 15px 0;\n}\n.choose-language .icon-down {\n  width: 30px;\n  height: auto;\n  margin: auto;\n}\n.lang-bg {\n  margin: 40px 0;\n}\n.lang-bg .lang-img {\n  width: 62px;\n  height: 62px;\n  margin: auto;\n}\n.lang-bg h3 {\n  text-align: center;\n  font-size: 22px;\n  font-weight: 500;\n  margin: 10px 0;\n  text-transform: capitalize;\n}\n.button-start {\n  margin: 50px auto 0 auto;\n  text-align: center;\n}\nion-button {\n  --background: var(--ion-color-second-app)!important;\n  --border-radius: 50px!important;\n  font-size: 22px !important;\n  font-weight: 500;\n  width: 90%;\n  height: 55px;\n  --box-shadow: 2px 4px 6px rgba(0, 0, 0, 0.16);\n}\nion-button ion-img {\n  max-width: 45px;\n  height: auto;\n}\n.button-start ion-img {\n  padding-right: 10px;\n}\nion-spinner {\n  text-align: center !important;\n  margin: auto;\n}\n.flag-border {\n  border: 5px solid red;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uXFwuLlxcLi5cXGNob29zZS1sYW5ndWFnZS5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBRUE7RUFDSSxrQkFBQTtFQUNBLGtDQUFBO0VBQ0EsMkJBQUE7RUFDQSxlQUFBO0VBQ0EscUJBQUE7QUFESjtBQUdFO0VBQ0UsV0FBQTtFQUNBLFlBQUE7RUFDQSxZQUFBO0FBREo7QUFPQTtFQUVFLGNBQUE7QUFMRjtBQU9FO0VBQ0UsV0FBQTtFQUNBLFlBQUE7RUFDQSxZQUFBO0FBTEo7QUFRRTtFQUNFLGtCQUFBO0VBQ0EsZUFBQTtFQUNBLGdCQUFBO0VBQ0EsY0FBQTtFQUNBLDBCQUFBO0FBTko7QUFlQTtFQUNFLHdCQUFBO0VBQ0Esa0JBQUE7QUFaRjtBQWVBO0VBQ0UsbURBQUE7RUFDQSwrQkFBQTtFQUNBLDBCQUFBO0VBQ0EsZ0JBQUE7RUFDQSxVQUFBO0VBQ0EsWUFBQTtFQUNBLDZDQUFBO0FBWkY7QUFjRTtFQUNFLGVBQUE7RUFDQSxZQUFBO0FBWko7QUFnQkE7RUFDRSxtQkFBQTtBQWJGO0FBZ0JBO0VBQ0UsNkJBQUE7RUFDQSxZQUFBO0FBYkY7QUFnQkE7RUFDRSxxQkFBQTtBQWJGIiwiZmlsZSI6ImNob29zZS1sYW5ndWFnZS5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIuY2hvb3NlLWxhbmd1YWdle1xyXG5cclxuaDEudGl0bGUge1xyXG4gICAgdGV4dC1hbGlnbjogY2VudGVyO1xyXG4gICAgY29sb3I6IHZhcigtLWlvbi1jb2xvci1zZWNvbmQtYXBwKTtcclxuICAgIGZvbnQtd2VpZ2h0OiA2MDAgIWltcG9ydGFudDtcclxuICAgIGZvbnQtc2l6ZTogMjVweDtcclxuICAgIG1hcmdpbjogNzBweCAwIDE1cHggMDtcclxuICB9XHJcbiAgLmljb24tZG93biB7XHJcbiAgICB3aWR0aDogMzBweDtcclxuICAgIGhlaWdodDogYXV0bztcclxuICAgIG1hcmdpbjogYXV0bztcclxuICB9XHJcblxyXG5cclxufVxyXG5cclxuLmxhbmctYmcge1xyXG5cclxuICBtYXJnaW46IDQwcHggMDtcclxuXHJcbiAgLmxhbmctaW1nIHtcclxuICAgIHdpZHRoOiA2MnB4O1xyXG4gICAgaGVpZ2h0OiA2MnB4O1xyXG4gICAgbWFyZ2luOiBhdXRvO1xyXG4gIH1cclxuXHJcbiAgaDMge1xyXG4gICAgdGV4dC1hbGlnbjogY2VudGVyO1xyXG4gICAgZm9udC1zaXplOiAyMnB4O1xyXG4gICAgZm9udC13ZWlnaHQ6IDUwMDtcclxuICAgIG1hcmdpbjogMTBweCAwO1xyXG4gICAgdGV4dC10cmFuc2Zvcm06IGNhcGl0YWxpemU7XHJcbiAgfVxyXG59XHJcblxyXG4vLyAubGFuZy1iZyBpb24taW1nIHtcclxuLy8gICB3aWR0aDogOTBweCFpbXBvcnRhbnQ7XHJcbi8vICAgbWFyZ2luOiAxNXB4IGF1dG87XHJcbi8vIH1cclxuXHJcbi5idXR0b24tc3RhcnQge1xyXG4gIG1hcmdpbjogNTBweCBhdXRvIDAgYXV0bztcclxuICB0ZXh0LWFsaWduOiBjZW50ZXI7XHJcbn1cclxuXHJcbmlvbi1idXR0b24ge1xyXG4gIC0tYmFja2dyb3VuZCA6IHZhcigtLWlvbi1jb2xvci1zZWNvbmQtYXBwKSFpbXBvcnRhbnQ7XHJcbiAgLS1ib3JkZXItcmFkaXVzOiA1MHB4IWltcG9ydGFudDtcclxuICBmb250LXNpemU6IDIycHggIWltcG9ydGFudDtcclxuICBmb250LXdlaWdodDogNTAwO1xyXG4gIHdpZHRoOiA5MCU7XHJcbiAgaGVpZ2h0OiA1NXB4O1xyXG4gIC0tYm94LXNoYWRvdzogMnB4IDRweCA2cHggcmdiYSgwLCAwLCAwLCAwLjE2KTtcclxuXHJcbiAgaW9uLWltZyB7XHJcbiAgICBtYXgtd2lkdGg6IDQ1cHg7XHJcbiAgICBoZWlnaHQ6IGF1dG87XHJcbiAgfVxyXG59XHJcblxyXG4uYnV0dG9uLXN0YXJ0IGlvbi1pbWcge1xyXG4gIHBhZGRpbmctcmlnaHQ6IDEwcHg7XHJcbn1cclxuXHJcbmlvbi1zcGlubmVyICB7XHJcbiAgdGV4dC1hbGlnbjogY2VudGVyIWltcG9ydGFudDtcclxuICBtYXJnaW46IGF1dG87XHJcbn1cclxuXHJcbi5mbGFnLWJvcmRlciB7XHJcbiAgYm9yZGVyOiA1cHggc29saWQgcmVkO1xyXG59XHJcblxyXG4iXX0= */");

/***/ })

}]);
//# sourceMappingURL=choose-language-choose-language-module.js.map