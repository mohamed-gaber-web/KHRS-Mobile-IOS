(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["puzzle-image-puzzle-image-module"],{

/***/ "NecZ":
/*!****************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/training/puzzle-image/puzzle-image.page.html ***!
  \****************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-header class=\"course\">\r\n  <ion-toolbar color=\"primary\">\r\n    <ion-buttons slot=\"start\">\r\n      <ion-back-button defaultHref=\"/exercise\"> </ion-back-button>\r\n    </ion-buttons>\r\n\r\n    <ion-menu-button slot=\"start\"></ion-menu-button>\r\n\r\n    <div class=\"img-profile\">\r\n      <ion-avatar slot=\"end\">\r\n        <img loading=\"lazy\" *ngIf=\"userInfo.imagePath\" [src]=\"userInfo.imagePath\">\r\n        <img loading=\"lazy\" *ngIf=\"userInfo === '' || userInfo.imagePath === null || userInfo.imagePath === undefined\"\r\n        src=\"../../../assets/images/image profille (1).png\">\r\n      </ion-avatar>\r\n      <ion-label>{{ userInfo.firstname + ' ' +  userInfo.lastname }}</ion-label>\r\n    </div>\r\n\r\n    <ion-avatar class=\"ion-margin-end\"  slot=\"end\">\r\n      <img class=\"img-langauge\" [src]=\"userInfo.languageIcon\">\r\n    </ion-avatar>  </ion-toolbar>\r\n</ion-header>\r\n\r\n\r\n<ion-toolbar>\r\n  <ion-title class=\"ion-text-center\">\r\n    Puzzle with image\r\n    <ion-text class=\"total-result\"> {{ lengthQuestion + ' / ' + (currentIndex+1) }} </ion-text>\r\n  </ion-title>\r\n  <ion-icon slot=\"end\" (click)=\"presentModal()\"  name=\"help-circle-outline\"></ion-icon>\r\n</ion-toolbar>\r\n\r\n<ion-content>\r\n\r\n  <ion-spinner *ngIf='isLoading' color=\"primary\" name=\"crescent\"></ion-spinner>\r\n\r\n  <ion-slides class=\"swiper-no-swiping\"  [pager]=\"false\" #slides [options]=\"slideOpts\">\r\n    <ion-slide>\r\n\r\n      <div cdkDropListGroup class=\"drag-group\">\r\n\r\n        <ion-grid>\r\n          <ion-row>\r\n            <ion-col size=\"12\" size-lg=\"6\">\r\n              <ion-grid>\r\n\r\n                <ion-row>\r\n\r\n                  <ion-col size=\"12\"\r\n                    class=\"example-box\"\r\n                    cdkDropList\r\n                    *ngFor=\"let item of questionsArray\"\r\n                    [cdkDropListData]=\"item\"\r\n                    cdkDropListSortingDisabled\r\n                    cdkDropListOrientation=\"horizontal\"\r\n                    (cdkDropListDropped)=\"drop($event)\"\r\n                  >\r\n                  <div *ngFor=\"let item2 of item\">\r\n\r\n                    <ion-img\r\n                      class=\"image-question\"\r\n                      loading=\"lazy\" *ngIf=\"item2.type === 'question' \"\r\n                      (click)=\"presentPopover($event, item2)\"\r\n                      [src]=\"item2.imagePath\" cdkDrag [cdkDragDisabled]=\"true\">\r\n                    </ion-img>\r\n\r\n\r\n                    <div class=\"drag-answer\" *ngIf=\"item2.type === 'answer' \">\r\n                      <ion-grid class=\"puzzle-answer\">\r\n                        <ion-row>\r\n\r\n                          <ion-col\r\n                            size=\"12\"\r\n                            >\r\n                            <div class=\"puzzle-fix\" cdkDrag [cdkDragDisabled]=\"false\">\r\n                              <div class=\"title\"> {{ item2.keyword }}</div>\r\n                              <div class=\"sound\" *ngIf=\"item2.voicePath\">\r\n                                <div class=\"sound-bg\">\r\n                                  <div class=\"img-volume\">\r\n                                    <ion-img\r\n                                    class=\"animate__animated animate__jello animate__delay-2s animate__bounce animate__repeat-2\" src=\"../../../assets/icon/Vector.png\" (click)=\"startAudio(item2.voicePath)\">\r\n                                  </ion-img>\r\n                                  </div>\r\n                                </div>\r\n                                <img class=\"danish-flag\" [src]=\"userInfo.languageIcon\" alt=\"\" />\r\n                              </div>\r\n                              <div class=\"sound\" *ngIf=\"item2.voicePathDanish\">\r\n                                <div class=\"sound-bg\">\r\n                                  <div class=\"img-volume\">\r\n                                    <ion-img\r\n                                    loading=\"lazy\"\r\n                                    class=\"animate__animated animate__jello animate__delay-2s animate__bounce animate__repeat-2\" src=\"../../../assets/icon/Vector.png\" (click)=\"startAudio(item2.voicePathDanish)\">\r\n                                  </ion-img>\r\n                                  </div>\r\n                                </div>\r\n                                <img loading=\"lazy\" class=\"danish-flag\" src=\"../../../assets/icon/da.png\" alt=\"\" />\r\n                              </div>\r\n                            </div>\r\n                          </ion-col>\r\n\r\n                        </ion-row>\r\n                      </ion-grid>\r\n\r\n                    </div>\r\n                  </div>\r\n\r\n                  </ion-col>\r\n\r\n                </ion-row>\r\n\r\n              </ion-grid>\r\n\r\n            </ion-col>\r\n\r\n            <ion-col size=\"12\" size-lg=\"6\">\r\n              <ion-grid class=\"puzzle-answer\">\r\n                <ion-row>\r\n                  <ion-col cdkDropList [cdkDropListData]=\"answersArray\" (cdkDropListDropped)=\"drop($event)\">\r\n                    <div class=\"puzzle-fix\" *ngFor=\"let item of answersArray\" cdkDrag>\r\n                      <div class=\"title\"> {{ item.keyword }}</div>\r\n                        <div class=\"sound\" *ngIf=\"item.voicePath\">\r\n                          <div class=\"sound-bg\">\r\n                            <div class=\"img-volume\">\r\n                              <ion-img\r\n                              class=\"animate__animated animate__jello animate__delay-2s animate__bounce animate__repeat-2\" src=\"../../../assets/icon/Vector.png\" (click)=\"startAudio(item.voicePath)\">\r\n                            </ion-img>\r\n                            </div>\r\n                          </div>\r\n                          <img class=\"danish-flag\" [src]=\"userInfo.languageIcon\" alt=\"\" />\r\n                        </div>\r\n                        <div class=\"sound\" *ngIf=\"item.voicePathDanish\">\r\n                          <div class=\"sound-bg\">\r\n                            <div class=\"img-volume\">\r\n                              <ion-img\r\n                              loading=\"lazy\"\r\n                              class=\"animate__animated animate__jello animate__delay-2s animate__bounce animate__repeat-2\" src=\"../../../assets/icon/Vector.png\" (click)=\"startAudio(item.voicePathDanish)\">\r\n                            </ion-img>\r\n                            </div>\r\n                          </div>\r\n                          <img loading=\"lazy\" class=\"danish-flag\" src=\"../../../assets/icon/da.png\" alt=\"\" />\r\n                        </div>\r\n                    </div>\r\n                  </ion-col>\r\n                </ion-row>\r\n            </ion-grid>\r\n            </ion-col>\r\n          </ion-row>\r\n        </ion-grid>\r\n\r\n\r\n\r\n\r\n        <ion-grid>\r\n          <ion-row class=\"ion-padding ion-justify-content-center\">\r\n\r\n            <ion-col size=\"12\" size-lg=\"6\">\r\n              <ion-button *ngIf=\"nextButton\" (click)=\"slidePrev()\">\r\n                Prev\r\n                <ion-icon name=\"chevron-forward-outline\"></ion-icon>\r\n              </ion-button>\r\n            </ion-col>\r\n\r\n            <ion-col size=\"12\" size-lg=\"6\">\r\n              <ion-button *ngIf=\"nextButton\" (click)=\"slideNext()\">\r\n                Next\r\n                <ion-icon name=\"chevron-forward-outline\"></ion-icon>\r\n              </ion-button>\r\n            </ion-col>\r\n          </ion-row>\r\n        </ion-grid>\r\n\r\n\r\n      </div>\r\n    </ion-slide>\r\n  </ion-slides>\r\n\r\n</ion-content>\r\n\r\n\r\n");

/***/ }),

/***/ "PFl2":
/*!**************************************************************!*\
  !*** ./src/app/training/puzzle-image/puzzle-image.module.ts ***!
  \**************************************************************/
/*! exports provided: PuzzleImagePageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PuzzleImagePageModule", function() { return PuzzleImagePageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "8Y7J");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "SVse");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "s7LF");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "sZkV");
/* harmony import */ var _puzzle_image_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./puzzle-image-routing.module */ "fcSu");
/* harmony import */ var _puzzle_sound_puzzle_sound_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./puzzle-sound/puzzle-sound.component */ "idoe");
/* harmony import */ var _puzzle_image_page__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./puzzle-image.page */ "szV/");
/* harmony import */ var _angular_cdk_drag_drop__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/cdk/drag-drop */ "ltgo");
/* harmony import */ var _puzzle_sound_puzzle_sound_module__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./puzzle-sound/puzzle-sound.module */ "dtX3");
/* harmony import */ var _help_modal_help_modal_module__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ../help-modal/help-modal.module */ "lCi7");











let PuzzleImagePageModule = class PuzzleImagePageModule {
};
PuzzleImagePageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
            _puzzle_image_routing_module__WEBPACK_IMPORTED_MODULE_5__["PuzzleImagePageRoutingModule"],
            _angular_cdk_drag_drop__WEBPACK_IMPORTED_MODULE_8__["DragDropModule"],
            _puzzle_sound_puzzle_sound_module__WEBPACK_IMPORTED_MODULE_9__["PuzzleSoundModule"],
            _help_modal_help_modal_module__WEBPACK_IMPORTED_MODULE_10__["HelpModalModule"]
        ],
        declarations: [_puzzle_image_page__WEBPACK_IMPORTED_MODULE_7__["PuzzleImagePage"]],
        exports: [],
        entryComponents: [_puzzle_sound_puzzle_sound_component__WEBPACK_IMPORTED_MODULE_6__["PuzzleSoundComponent"]],
    })
], PuzzleImagePageModule);



/***/ }),

/***/ "Tv6U":
/*!********************************************************************************!*\
  !*** ./src/app/training/puzzle-image/puzzle-sound/puzzle-sound.component.scss ***!
  \********************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (".popover-content.sc-ion-popover-md {\n  position: static !important;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uXFwuLlxcLi5cXC4uXFwuLlxccHV6emxlLXNvdW5kLmNvbXBvbmVudC5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQXdDQTtFQUNFLDJCQUFBO0FBdkNGIiwiZmlsZSI6InB1enpsZS1zb3VuZC5jb21wb25lbnQuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi8vIC5leHQtaWNvbi12bHVtZSB7XHJcbi8vICAgd2lkdGg6IDI0cHg7XHJcbi8vICAgaGVpZ2h0OiAyNHB4O1xyXG4vLyB9XHJcblxyXG5cclxuXHJcblxyXG4vLyAuc291bmQtcG9wdXAge1xyXG5cclxuXHJcblxyXG4vLyAgIHBhZGRpbmc6IDIwcHg7XHJcblxyXG4vLyAgIC5zb3VuZCB7XHJcbi8vICAgICBkaXNwbGF5OiBmbGV4O1xyXG4vLyAgICAgYm9yZGVyOiAycHggc29saWQgdmFyKC0taW9uLWNvbG9yLXNlY29uZC1hcHApO1xyXG4vLyAgICAgYm9yZGVyLXJhZGl1czoxMHB4O1xyXG4vLyAgICAgcGFkZGluZzogNXB4IDRweDtcclxuLy8gICAgIG1hcmdpbjogMTBweDtcclxuXHJcbi8vICAgICAuc291bmQtYmcge1xyXG4vLyAgICAgICB3aWR0aDogMjBweDtcclxuLy8gICAgICAgaGVpZ2h0OiAyMHB4O1xyXG4vLyAgICAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XHJcbi8vICAgICAgIGJvcmRlci1yYWRpdXM6IDUwcHg7XHJcbi8vICAgICAgIG1hcmdpbi1yaWdodDogMTBweDtcclxuXHJcbi8vICAgICAgIC5pbWctdm9sdW1lIHtcclxuLy8gICAgICAgICBAZXh0ZW5kIC5leHQtaWNvbi12bHVtZTtcclxuLy8gICAgICAgfVxyXG4vLyAgICAgfVxyXG4vLyAgIH1cclxuLy8gfVxyXG5cclxuLy8gLmRhbmlzaC1mbGFnIHtcclxuLy8gICB3aWR0aDogMzBweDtcclxuLy8gICBoZWlnaHQ6IGF1dG87XHJcbi8vIH1cclxuXHJcbi5wb3BvdmVyLWNvbnRlbnQuc2MtaW9uLXBvcG92ZXItbWQge1xyXG4gIHBvc2l0aW9uOiBzdGF0aWMhaW1wb3J0YW50O1xyXG59XHJcbiJdfQ== */");

/***/ }),

/***/ "cmRR":
/*!**************************************************************!*\
  !*** ./src/app/training/puzzle-image/puzzle-image.page.scss ***!
  \**************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (".ext-icon-vlume, .puzzle-answer .puzzle-fix .sound .sound-bg .img-volume {\n  width: 24px;\n  height: 24px;\n  display: flex;\n  align-items: center;\n  padding: 15px 0px;\n}\n\n/* header Top */\n\nion-header ion-img {\n  width: 35px;\n  height: auto;\n  margin-top: 10px;\n}\n\n.img-profile {\n  display: flex;\n  justify-content: center;\n  align-items: center;\n}\n\n.img-profile ion-avatar {\n  width: 60px;\n  margin: 5px 0;\n  height: 60px;\n}\n\n.img-profile ion-label {\n  font-size: 14 px;\n  padding-left: 10px;\n}\n\n/* end header top */\n\nion-toolbar ion-icon {\n  color: var(--ion-color-second-app);\n  font-size: 30px;\n  margin-right: 20px;\n  margin-top: 24px;\n}\n\nion-img.image-question {\n  width: 80px;\n  height: 80px;\n  padding: 0;\n  margin: 0;\n}\n\n@media (min-width: 768px) {\n  ion-img {\n    width: 70%;\n    height: auto;\n    margin: auto;\n  }\n}\n\n.puzzle-answer {\n  margin-top: 20px;\n}\n\n.puzzle-answer .puzzle-fix {\n  display: flex;\n  justify-content: space-between;\n  align-items: center;\n  background-color: #fff;\n  padding: 5px 10px;\n  margin: 10px 0;\n  border: 2px dotted #003182a6;\n  height: 50px;\n}\n\n.puzzle-answer .puzzle-fix .title {\n  font-size: 14px;\n  font-weight: 500;\n  color: var(--ion-color-second-app);\n}\n\n.puzzle-answer .puzzle-fix .sound {\n  display: flex;\n  border: 2px dotted var(--ion-color-second-app);\n  border-radius: 10px;\n  padding: 5px 4px;\n}\n\n.puzzle-answer .puzzle-fix .sound .sound-bg {\n  width: 20px;\n  height: 20px;\n  text-align: center;\n  border-radius: 50px;\n  margin-right: 10px;\n}\n\n.img-langauge {\n  width: 40px;\n  height: 40px;\n  position: absolute;\n  right: 13px;\n  top: 14px;\n  border: 1px solid #ccc;\n}\n\n.drag-answer .puzzle-img ion-img {\n  width: 20px !important;\n  height: 20px !important;\n}\n\n.drag-answer .puzzle-answer {\n  margin-top: 0;\n  padding: 5px 0 !important;\n}\n\n.drag-answer .title {\n  margin-top: 0 !important;\n}\n\n.drag-answer .sound {\n  display: flex;\n}\n\n.drag-answer .sound .sound-bg img {\n  width: 50px !important;\n  height: auto;\n}\n\n.drag-answer .sound .img-volume ion-img {\n  width: 20px;\n  height: auto;\n}\n\n/************* DRAG AND DROP *****************/\n\n.example-box {\n  border: 2px dotted #003182a6 !important;\n  color: rgba(0, 0, 0, 0.87);\n  display: flex;\n  flex-direction: row;\n  align-items: center;\n  justify-content: flex-start;\n  cursor: move;\n  background: white;\n  font-size: 16px;\n  border-radius: 0;\n  margin: 5px 0;\n  height: auto;\n  padding: 0;\n}\n\n.example-box .sound {\n  padding: 0 5px 0 10px;\n}\n\n.example-box .title {\n  margin-right: 5px;\n}\n\n.example-box img.danish-flag {\n  width: 24px;\n  height: auto;\n}\n\n.example-box .drag-answer ion-img {\n  width: 50px;\n  height: auto;\n  position: relative;\n  top: -2px;\n}\n\n.cdk-drag-preview {\n  box-sizing: border-box;\n  border-radius: 4px;\n  box-shadow: 0 5px 5px -3px rgba(0, 0, 0, 0.2), 0 8px 10px 1px rgba(0, 0, 0, 0.14), 0 3px 14px 2px rgba(0, 0, 0, 0.12);\n  background-color: white;\n  padding: 10px !important;\n  width: 80% !important;\n  margin: auto;\n  height: auto !important;\n  font-size: 13px;\n  font-weight: 600;\n  color: var(--ion-color-second-app);\n}\n\n.cdk-drag-preview .sound-bg {\n  display: inline-block;\n  width: 30px;\n  height: 30px;\n  margin: 10px 20px;\n}\n\n.cdk-drag-preview .img-volume {\n  text-align: center;\n  margin: auto;\n  width: 18px;\n  height: 18px;\n}\n\n.cdk-drag-preview .puzzle-fix .title {\n  font-weight: 600 !important;\n  padding: 0 5px !important;\n}\n\n.cdk-drag-preview .puzzle-fix img.danish-flag {\n  width: 24px;\n  height: 24px;\n  max-width: 70%;\n}\n\n.cdk-drop-list-receiving {\n  background-color: rgba(167, 247, 129, 0.6);\n  color: var(--ion-color-second-app);\n}\n\n.cdk-drop-list-dragging {\n  background-color: rgba(167, 247, 129, 0.6);\n  color: var(--ion-color-second-app);\n}\n\n.cdk-drag-placeholder {\n  opacity: 0;\n}\n\n.cdk-drag-animating {\n  transition: transform 120ms cubic-bezier(0, 0, 0.2, 3);\n}\n\n.example-box:last-child {\n  border: none;\n}\n\n.example-list.cdk-drop-list-dragging .example-box:not(.cdk-drag-placeholder) {\n  transition: transform 250ms cubic-bezier(0, 0, 0.2, 1);\n}\n\n/************* DRAG AND DROP *****************/\n\n.total-result {\n  font-size: 18px;\n  font-weight: 900;\n  color: var(--ion-color-second-app);\n  text-align: center;\n  margin-left: 50px;\n}\n\n.popover-content.sc-ion-popover-md {\n  position: static !important;\n}\n\n.drag-group {\n  width: 100%;\n}\n\n@media (min-width: 1200px) {\n  .cdk-drag-preview {\n    width: 30% !important;\n  }\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uXFwuLlxcLi5cXC4uXFxwdXp6bGUtaW1hZ2UucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0UsV0FBQTtFQUNBLFlBQUE7RUFDQSxhQUFBO0VBQ0EsbUJBQUE7RUFDQSxpQkFBQTtBQUNGOztBQUVBLGVBQUE7O0FBQ0E7RUFDRSxXQUFBO0VBQ0EsWUFBQTtFQUNBLGdCQUFBO0FBQ0Y7O0FBR0E7RUFDRSxhQUFBO0VBQ0EsdUJBQUE7RUFDQSxtQkFBQTtBQUFGOztBQUVFO0VBQ0UsV0FBQTtFQUNBLGFBQUE7RUFDQSxZQUFBO0FBQUo7O0FBR0U7RUFDRSxnQkFBQTtFQUNBLGtCQUFBO0FBREo7O0FBS0EsbUJBQUE7O0FBSUU7RUFDRSxrQ0FBQTtFQUNBLGVBQUE7RUFDQSxrQkFBQTtFQUNBLGdCQUFBO0FBTEo7O0FBU0U7RUFDRSxXQUFBO0VBQ0EsWUFBQTtFQUNBLFVBQUE7RUFDQSxTQUFBO0FBTko7O0FBU0U7RUFDRTtJQUNFLFVBQUE7SUFDQSxZQUFBO0lBQ0EsWUFBQTtFQU5KO0FBQ0Y7O0FBVUE7RUFDRSxnQkFBQTtBQVJGOztBQVNFO0VBRUUsYUFBQTtFQUNBLDhCQUFBO0VBQ0EsbUJBQUE7RUFDQSxzQkFBQTtFQUNBLGlCQUFBO0VBQ0EsY0FBQTtFQUNBLDRCQUFBO0VBQ0EsWUFBQTtBQVJKOztBQVVJO0VBQ0UsZUFBQTtFQUNBLGdCQUFBO0VBQ0Esa0NBQUE7QUFSTjs7QUFhSTtFQUNFLGFBQUE7RUFDQSw4Q0FBQTtFQUNBLG1CQUFBO0VBQ0EsZ0JBQUE7QUFYTjs7QUFhTTtFQUNFLFdBQUE7RUFDQSxZQUFBO0VBQ0Esa0JBQUE7RUFDQSxtQkFBQTtFQUNBLGtCQUFBO0FBWFI7O0FBd0JBO0VBQ0UsV0FBQTtFQUNBLFlBQUE7RUFDQSxrQkFBQTtFQUNBLFdBQUE7RUFDQSxTQUFBO0VBQ0Esc0JBQUE7QUF0QkY7O0FBNkJFO0VBQ0Usc0JBQUE7RUFDQSx1QkFBQTtBQTFCSjs7QUE2QkU7RUFDRSxhQUFBO0VBQ0EseUJBQUE7QUEzQko7O0FBOEJFO0VBQ0Usd0JBQUE7QUE1Qko7O0FBK0JFO0VBQ0UsYUFBQTtBQTdCSjs7QUFpQ007RUFDRSxzQkFBQTtFQUNBLFlBQUE7QUEvQlI7O0FBbUNJO0VBQ0UsV0FBQTtFQUNBLFlBQUE7QUFqQ047O0FBeUNBLDhDQUFBOztBQUVBO0VBQ0UsdUNBQUE7RUFDQSwwQkFBQTtFQUNBLGFBQUE7RUFDQSxtQkFBQTtFQUNBLG1CQUFBO0VBQ0EsMkJBQUE7RUFFQSxZQUFBO0VBQ0EsaUJBQUE7RUFDQSxlQUFBO0VBQ0EsZ0JBQUE7RUFDQSxhQUFBO0VBQ0EsWUFBQTtFQUNBLFVBQUE7QUF4Q0Y7O0FBMENFO0VBQ0UscUJBQUE7QUF4Q0o7O0FBMkNFO0VBQVEsaUJBQUE7QUF4Q1Y7O0FBMENFO0VBQ0UsV0FBQTtFQUNBLFlBQUE7QUF4Q0o7O0FBMkNBO0VBQ0UsV0FBQTtFQUNBLFlBQUE7RUFDQSxrQkFBQTtFQUNBLFNBQUE7QUF6Q0Y7O0FBNkNBO0VBRUUsc0JBQUE7RUFDQSxrQkFBQTtFQUNBLHFIQUFBO0VBR0EsdUJBQUE7RUFDQSx3QkFBQTtFQUNBLHFCQUFBO0VBQ0EsWUFBQTtFQUNBLHVCQUFBO0VBQ0EsZUFBQTtFQUNBLGdCQUFBO0VBQ0Esa0NBQUE7QUE3Q0Y7O0FBaURFO0VBQ0UscUJBQUE7RUFDQSxXQUFBO0VBQ0EsWUFBQTtFQUNBLGlCQUFBO0FBL0NKOztBQWtERTtFQUNFLGtCQUFBO0VBQ0EsWUFBQTtFQUNBLFdBQUE7RUFDQSxZQUFBO0FBaERKOztBQXNESTtFQUNFLDJCQUFBO0VBQ0EseUJBQUE7QUFwRE47O0FBdURJO0VBQ0UsV0FBQTtFQUNBLFlBQUE7RUFDQSxjQUFBO0FBckROOztBQTREQTtFQUNFLDBDQUFBO0VBQ0Esa0NBQUE7QUF6REY7O0FBNERBO0VBQ0UsMENBQUE7RUFDQSxrQ0FBQTtBQXpERjs7QUE2REE7RUFDRSxVQUFBO0FBMURGOztBQTZEQTtFQUNFLHNEQUFBO0FBMURGOztBQTZEQTtFQUNFLFlBQUE7QUExREY7O0FBNkRBO0VBQ0Usc0RBQUE7QUExREY7O0FBb0ZBLDhDQUFBOztBQUVBO0VBQ0UsZUFBQTtFQUNBLGdCQUFBO0VBQ0Esa0NBQUE7RUFDQSxrQkFBQTtFQUNBLGlCQUFBO0FBbEZGOztBQXFGQTtFQUNBLDJCQUFBO0FBbEZBOztBQXFGQTtFQUNFLFdBQUE7QUFsRkY7O0FBc0ZBO0VBQ0U7SUFDRSxxQkFBQTtFQW5GRjtBQUNGIiwiZmlsZSI6InB1enpsZS1pbWFnZS5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIuZXh0LWljb24tdmx1bWUge1xyXG4gIHdpZHRoOiAyNHB4O1xyXG4gIGhlaWdodDogMjRweDtcclxuICBkaXNwbGF5OiBmbGV4O1xyXG4gIGFsaWduLWl0ZW1zOiBjZW50ZXI7XHJcbiAgcGFkZGluZzogMTVweCAwcHg7XHJcbn1cclxuXHJcbi8qIGhlYWRlciBUb3AgKi9cclxuaW9uLWhlYWRlciBpb24taW1nIHtcclxuICB3aWR0aDogMzVweDtcclxuICBoZWlnaHQ6IGF1dG87XHJcbiAgbWFyZ2luLXRvcDogMTBweDtcclxufVxyXG5cclxuXHJcbi5pbWctcHJvZmlsZSB7XHJcbiAgZGlzcGxheTogZmxleDtcclxuICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcclxuICBhbGlnbi1pdGVtczogY2VudGVyO1xyXG5cclxuICBpb24tYXZhdGFyIHtcclxuICAgIHdpZHRoOiA2MHB4O1xyXG4gICAgbWFyZ2luOiA1cHggMDtcclxuICAgIGhlaWdodDogNjBweDtcclxuICB9XHJcblxyXG4gIGlvbi1sYWJlbCB7XHJcbiAgICBmb250LXNpemU6IDE0IHB4O1xyXG4gICAgcGFkZGluZy1sZWZ0OiAxMHB4O1xyXG4gIH1cclxufVxyXG5cclxuLyogZW5kIGhlYWRlciB0b3AgKi9cclxuXHJcbmlvbi10b29sYmFyIHtcclxuXHJcbiAgaW9uLWljb24ge1xyXG4gICAgY29sb3I6IHZhcigtLWlvbi1jb2xvci1zZWNvbmQtYXBwKTtcclxuICAgIGZvbnQtc2l6ZTogMzBweDtcclxuICAgIG1hcmdpbi1yaWdodDogMjBweDtcclxuICAgIG1hcmdpbi10b3A6IDI0cHg7XHJcbiAgfVxyXG59XHJcblxyXG4gIGlvbi1pbWcuaW1hZ2UtcXVlc3Rpb24ge1xyXG4gICAgd2lkdGg6IDgwcHg7XHJcbiAgICBoZWlnaHQ6IDgwcHg7XHJcbiAgICBwYWRkaW5nOiAwO1xyXG4gICAgbWFyZ2luOiAwO1xyXG4gIH1cclxuXHJcbiAgQG1lZGlhIChtaW4td2lkdGg6IDc2OHB4KSB7XHJcbiAgICBpb24taW1nIHtcclxuICAgICAgd2lkdGg6IDcwJTtcclxuICAgICAgaGVpZ2h0OiBhdXRvO1xyXG4gICAgICBtYXJnaW46IGF1dG87XHJcbiAgICB9XHJcbiAgfVxyXG5cclxuXHJcbi5wdXp6bGUtYW5zd2VyIHtcclxuICBtYXJnaW4tdG9wOiAyMHB4O1xyXG4gIC5wdXp6bGUtZml4IHtcclxuXHJcbiAgICBkaXNwbGF5OiBmbGV4O1xyXG4gICAganVzdGlmeS1jb250ZW50OiBzcGFjZS1iZXR3ZWVuO1xyXG4gICAgYWxpZ24taXRlbXM6IGNlbnRlcjtcclxuICAgIGJhY2tncm91bmQtY29sb3I6ICNmZmY7XHJcbiAgICBwYWRkaW5nOiA1cHggMTBweDtcclxuICAgIG1hcmdpbjogMTBweCAwO1xyXG4gICAgYm9yZGVyOiAycHggZG90dGVkICMwMDMxODJhNjtcclxuICAgIGhlaWdodDogNTBweDtcclxuXHJcbiAgICAudGl0bGUge1xyXG4gICAgICBmb250LXNpemU6IDE0cHg7XHJcbiAgICAgIGZvbnQtd2VpZ2h0OiA1MDA7XHJcbiAgICAgIGNvbG9yOiB2YXIoLS1pb24tY29sb3Itc2Vjb25kLWFwcCk7XHJcblxyXG4gICAgICAvLyBtYXJnaW4tdG9wOiAxN3B4O1xyXG4gICAgfVxyXG5cclxuICAgIC5zb3VuZCB7XHJcbiAgICAgIGRpc3BsYXk6IGZsZXg7XHJcbiAgICAgIGJvcmRlcjogMnB4IGRvdHRlZCB2YXIoLS1pb24tY29sb3Itc2Vjb25kLWFwcCk7XHJcbiAgICAgIGJvcmRlci1yYWRpdXM6MTBweDtcclxuICAgICAgcGFkZGluZzogNXB4IDRweDtcclxuXHJcbiAgICAgIC5zb3VuZC1iZyB7XHJcbiAgICAgICAgd2lkdGg6IDIwcHg7XHJcbiAgICAgICAgaGVpZ2h0OiAyMHB4O1xyXG4gICAgICAgIHRleHQtYWxpZ246IGNlbnRlcjtcclxuICAgICAgICBib3JkZXItcmFkaXVzOiA1MHB4O1xyXG4gICAgICAgIG1hcmdpbi1yaWdodDogMTBweDtcclxuXHJcbiAgICAgICAgLmltZy12b2x1bWUge1xyXG4gICAgICAgICAgQGV4dGVuZCAuZXh0LWljb24tdmx1bWU7XHJcbiAgICAgICAgfVxyXG4gICAgICB9XHJcbiAgICB9XHJcblxyXG4gIH1cclxuXHJcbn1cclxuXHJcblxyXG4uaW1nLWxhbmdhdWdlIHtcclxuICB3aWR0aDogNDBweDtcclxuICBoZWlnaHQ6IDQwcHg7XHJcbiAgcG9zaXRpb246IGFic29sdXRlO1xyXG4gIHJpZ2h0OiAxM3B4O1xyXG4gIHRvcDogMTRweDtcclxuICBib3JkZXI6IDFweCBzb2xpZCAjY2NjO1xyXG59XHJcblxyXG5cclxuLmRyYWctYW5zd2VyIHtcclxuXHJcblxyXG4gIC5wdXp6bGUtaW1nIGlvbi1pbWd7XHJcbiAgICB3aWR0aDogMjBweCFpbXBvcnRhbnQ7XHJcbiAgICBoZWlnaHQ6IDIwcHghaW1wb3J0YW50O1xyXG4gIH1cclxuXHJcbiAgLnB1enpsZS1hbnN3ZXJ7XHJcbiAgICBtYXJnaW4tdG9wOiAwO1xyXG4gICAgcGFkZGluZzogNXB4IDAgIWltcG9ydGFudDtcclxuICB9XHJcblxyXG4gIC50aXRsZSB7XHJcbiAgICBtYXJnaW4tdG9wOiAwICFpbXBvcnRhbnQ7XHJcbiAgfVxyXG5cclxuICAuc291bmR7XHJcbiAgICBkaXNwbGF5OiBmbGV4O1xyXG5cclxuICAgIC5zb3VuZC1iZyB7XHJcblxyXG4gICAgICBpbWcge1xyXG4gICAgICAgIHdpZHRoOiA1MHB4IWltcG9ydGFudDtcclxuICAgICAgICBoZWlnaHQ6IGF1dG87XHJcbiAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICAuaW1nLXZvbHVtZSBpb24taW1nIHtcclxuICAgICAgd2lkdGg6IDIwcHg7XHJcbiAgICAgIGhlaWdodDogYXV0bztcclxuICB9XHJcbiAgfVxyXG5cclxuXHJcbn1cclxuXHJcblxyXG4vKioqKioqKioqKioqKiBEUkFHIEFORCBEUk9QICoqKioqKioqKioqKioqKioqL1xyXG5cclxuLmV4YW1wbGUtYm94IHtcclxuICBib3JkZXI6IDJweCBkb3R0ZWQgIzAwMzE4MmE2IWltcG9ydGFudDtcclxuICBjb2xvcjogcmdiYSgwLCAwLCAwLCAwLjg3KTtcclxuICBkaXNwbGF5OiBmbGV4O1xyXG4gIGZsZXgtZGlyZWN0aW9uOiByb3c7XHJcbiAgYWxpZ24taXRlbXM6IGNlbnRlcjtcclxuICBqdXN0aWZ5LWNvbnRlbnQ6IGZsZXgtc3RhcnQ7XHJcbiAgLy8gYm94LXNpemluZzogYm9yZGVyLWJveDtcclxuICBjdXJzb3I6IG1vdmU7XHJcbiAgYmFja2dyb3VuZDogd2hpdGU7XHJcbiAgZm9udC1zaXplOiAxNnB4O1xyXG4gIGJvcmRlci1yYWRpdXM6IDA7XHJcbiAgbWFyZ2luOiA1cHggMDtcclxuICBoZWlnaHQ6IGF1dG87XHJcbiAgcGFkZGluZzogMDtcclxuXHJcbiAgLnNvdW5kIHtcclxuICAgIHBhZGRpbmc6IDAgNXB4IDAgMTBweDtcclxuICB9XHJcblxyXG4gIC50aXRsZSB7bWFyZ2luLXJpZ2h0OiA1cHg7fVxyXG5cclxuICBpbWcuZGFuaXNoLWZsYWcge1xyXG4gICAgd2lkdGg6IDI0cHg7XHJcbiAgICBoZWlnaHQ6IGF1dG87XHJcbn1cclxuXHJcbi5kcmFnLWFuc3dlciBpb24taW1ne1xyXG4gIHdpZHRoOiA1MHB4O1xyXG4gIGhlaWdodDogYXV0bztcclxuICBwb3NpdGlvbjogcmVsYXRpdmU7XHJcbiAgdG9wOiAtMnB4O1xyXG59XHJcbn1cclxuXHJcbi5jZGstZHJhZy1wcmV2aWV3IHtcclxuXHJcbiAgYm94LXNpemluZzogYm9yZGVyLWJveDtcclxuICBib3JkZXItcmFkaXVzOiA0cHg7XHJcbiAgYm94LXNoYWRvdzogMCA1cHggNXB4IC0zcHggcmdiYSgwLCAwLCAwLCAwLjIpLFxyXG4gICAgICAgICAgICAgIDAgOHB4IDEwcHggMXB4IHJnYmEoMCwgMCwgMCwgMC4xNCksXHJcbiAgICAgICAgICAgICAgMCAzcHggMTRweCAycHggcmdiYSgwLCAwLCAwLCAwLjEyKTtcclxuICBiYWNrZ3JvdW5kLWNvbG9yOiB3aGl0ZTtcclxuICBwYWRkaW5nOiAxMHB4IWltcG9ydGFudDtcclxuICB3aWR0aDogODAlIWltcG9ydGFudDtcclxuICBtYXJnaW46IGF1dG87XHJcbiAgaGVpZ2h0OiBhdXRvIWltcG9ydGFudDtcclxuICBmb250LXNpemU6IDEzcHg7XHJcbiAgZm9udC13ZWlnaHQ6IDYwMDtcclxuICBjb2xvcjogdmFyKC0taW9uLWNvbG9yLXNlY29uZC1hcHApO1xyXG5cclxuXHJcblxyXG4gIC5zb3VuZC1iZyB7XHJcbiAgICBkaXNwbGF5OiBpbmxpbmUtYmxvY2s7XHJcbiAgICB3aWR0aDogMzBweDtcclxuICAgIGhlaWdodDogMzBweDtcclxuICAgIG1hcmdpbjogMTBweCAyMHB4O1xyXG4gIH1cclxuXHJcbiAgLmltZy12b2x1bWUge1xyXG4gICAgdGV4dC1hbGlnbjogY2VudGVyO1xyXG4gICAgbWFyZ2luOiBhdXRvO1xyXG4gICAgd2lkdGg6IDE4cHg7XHJcbiAgICBoZWlnaHQ6IDE4cHg7XHJcbiAgfVxyXG5cclxuXHJcblxyXG4gIC5wdXp6bGUtZml4IHtcclxuICAgIC50aXRsZXtcclxuICAgICAgZm9udC13ZWlnaHQ6IDYwMCFpbXBvcnRhbnQ7XHJcbiAgICAgIHBhZGRpbmc6IDAgNXB4IWltcG9ydGFudDtcclxuICAgIH1cclxuXHJcbiAgICBpbWcuZGFuaXNoLWZsYWcge1xyXG4gICAgICB3aWR0aDogMjRweDtcclxuICAgICAgaGVpZ2h0OiAyNHB4O1xyXG4gICAgICBtYXgtd2lkdGg6IDcwJTtcclxufVxyXG5cclxuICB9XHJcblxyXG59XHJcblxyXG4uY2RrLWRyb3AtbGlzdC1yZWNlaXZpbmcge1xyXG4gIGJhY2tncm91bmQtY29sb3I6cmdiYSgxNjcsIDI0NywgMTI5LCAwLjYpO1xyXG4gIGNvbG9yOiB2YXIoLS1pb24tY29sb3Itc2Vjb25kLWFwcCk7XHJcbn1cclxuXHJcbi5jZGstZHJvcC1saXN0LWRyYWdnaW5ne1xyXG4gIGJhY2tncm91bmQtY29sb3I6cmdiYSgxNjcsIDI0NywgMTI5LCAwLjYpO1xyXG4gIGNvbG9yOiB2YXIoLS1pb24tY29sb3Itc2Vjb25kLWFwcCk7XHJcbn1cclxuXHJcblxyXG4uY2RrLWRyYWctcGxhY2Vob2xkZXIge1xyXG4gIG9wYWNpdHk6IDA7XHJcbn1cclxuXHJcbi5jZGstZHJhZy1hbmltYXRpbmcge1xyXG4gIHRyYW5zaXRpb246IHRyYW5zZm9ybSAxMjBtcyBjdWJpYy1iZXppZXIoMCwgMCwgMC4yLCAzKTtcclxufVxyXG5cclxuLmV4YW1wbGUtYm94Omxhc3QtY2hpbGQge1xyXG4gIGJvcmRlcjogbm9uZTtcclxufVxyXG5cclxuLmV4YW1wbGUtbGlzdC5jZGstZHJvcC1saXN0LWRyYWdnaW5nIC5leGFtcGxlLWJveDpub3QoLmNkay1kcmFnLXBsYWNlaG9sZGVyKSB7XHJcbiAgdHJhbnNpdGlvbjogdHJhbnNmb3JtIDI1MG1zIGN1YmljLWJlemllcigwLCAwLCAwLjIsIDEpO1xyXG59XHJcblxyXG4vLyAuZHJvcC1pdGVtIHtcclxuLy8gICBib3JkZXI6IDIwMHB4IGRvdHRlZCByZWQ7XHJcbi8vICAgZm9udC1zaXplOiAyMHB4O1xyXG4vLyAgIGJvcmRlci1yYWRpdXM6IDEwcHg7XHJcbi8vICAgd2lkdGg6IDEwMCU7XHJcbi8vICAgaGVpZ2h0OiAxMDAlO1xyXG4vLyB9XHJcblxyXG5cclxuLy8gLmV4YW1wbGUtY3VzdG9tLXBsYWNlaG9sZGVyIHtcclxuLy8gICBiYWNrZ3JvdW5kOiAjY2NjO1xyXG4vLyAgIGJvcmRlcjogZG90dGVkIDNweCAjOTk5O1xyXG4vLyAgIG1pbi1oZWlnaHQ6IDYwcHg7XHJcbi8vICAgdHJhbnNpdGlvbjogdHJhbnNmb3JtIDI1MG1zIGN1YmljLWJlemllcigwLCAwLCAwLjIsIDEpO1xyXG4vLyB9XHJcblxyXG4vLyAuY2RrLWRyYWcgIHtcclxuLy8gICBiYWNrZ3JvdW5kLWNvbG9yOiAjQTdGNzgxO1xyXG4vLyAgIGNvbG9yOiB2YXIoLS1pb24tY29sb3Itc2Vjb25kLWFwcCk7XHJcbi8vIH1cclxuXHJcblxyXG5cclxuLyoqKioqKioqKioqKiogRFJBRyBBTkQgRFJPUCAqKioqKioqKioqKioqKioqKi9cclxuXHJcbi50b3RhbC1yZXN1bHQge1xyXG4gIGZvbnQtc2l6ZTogMThweDtcclxuICBmb250LXdlaWdodDogOTAwO1xyXG4gIGNvbG9yOiB2YXIoLS1pb24tY29sb3Itc2Vjb25kLWFwcCk7XHJcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xyXG4gIG1hcmdpbi1sZWZ0OiA1MHB4O1xyXG59XHJcblxyXG4ucG9wb3Zlci1jb250ZW50LnNjLWlvbi1wb3BvdmVyLW1kIHtcclxucG9zaXRpb246IHN0YXRpYyFpbXBvcnRhbnQ7XHJcbn1cclxuXHJcbi5kcmFnLWdyb3VwIHtcclxuICB3aWR0aDogMTAwJTtcclxufVxyXG5cclxuXHJcbkBtZWRpYSAobWluLXdpZHRoOiAxMjAwcHgpIHtcclxuICAuY2RrLWRyYWctcHJldmlldyB7XHJcbiAgICB3aWR0aDogMzAlIWltcG9ydGFudDtcclxuXHJcbiAgICAgIH1cclxuXHJcbn1cclxuIl19 */");

/***/ }),

/***/ "dtX3":
/*!***************************************************************************!*\
  !*** ./src/app/training/puzzle-image/puzzle-sound/puzzle-sound.module.ts ***!
  \***************************************************************************/
/*! exports provided: PuzzleSoundModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PuzzleSoundModule", function() { return PuzzleSoundModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common */ "SVse");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ "8Y7J");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic/angular */ "sZkV");
/* harmony import */ var _puzzle_sound_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./puzzle-sound.component */ "idoe");





let PuzzleSoundModule = class PuzzleSoundModule {
};
PuzzleSoundModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_1__["CommonModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["IonicModule"],
        ],
        declarations: [_puzzle_sound_component__WEBPACK_IMPORTED_MODULE_4__["PuzzleSoundComponent"]]
    })
], PuzzleSoundModule);



/***/ }),

/***/ "fcSu":
/*!**********************************************************************!*\
  !*** ./src/app/training/puzzle-image/puzzle-image-routing.module.ts ***!
  \**********************************************************************/
/*! exports provided: PuzzleImagePageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PuzzleImagePageRoutingModule", function() { return PuzzleImagePageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "8Y7J");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "iInd");
/* harmony import */ var _puzzle_image_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./puzzle-image.page */ "szV/");




const routes = [
    {
        path: '',
        component: _puzzle_image_page__WEBPACK_IMPORTED_MODULE_3__["PuzzleImagePage"]
    }
];
let PuzzleImagePageRoutingModule = class PuzzleImagePageRoutingModule {
};
PuzzleImagePageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], PuzzleImagePageRoutingModule);



/***/ }),

/***/ "idoe":
/*!******************************************************************************!*\
  !*** ./src/app/training/puzzle-image/puzzle-sound/puzzle-sound.component.ts ***!
  \******************************************************************************/
/*! exports provided: PuzzleSoundComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PuzzleSoundComponent", function() { return PuzzleSoundComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _raw_loader_puzzle_sound_component_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! raw-loader!./puzzle-sound.component.html */ "lz/e");
/* harmony import */ var _puzzle_sound_component_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./puzzle-sound.component.scss */ "Tv6U");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ "8Y7J");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "sZkV");
/* harmony import */ var howler__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! howler */ "HlzF");
/* harmony import */ var howler__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(howler__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var src_app_auth_auth_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! src/app/auth/auth.service */ "qXBG");







let PuzzleSoundComponent = class PuzzleSoundComponent {
    constructor(modalController, navParams, authService) {
        this.modalController = modalController;
        this.navParams = navParams;
        this.authService = authService;
        //howler
        this.player = null;
        this.isPlaying = false;
    }
    ngOnInit() {
        this.userInfo = this.authService.getUser();
        this.voicePath = this.navParams.data.voicePath;
        this.voicePathDanish = this.navParams.data.voicePathDanish;
        this.imagePath = this.navParams.data.imagePath;
    }
    startAudio(voicePath) {
        if (this.player) {
            this.player.stop();
        }
        this.player = new howler__WEBPACK_IMPORTED_MODULE_5__["Howl"]({
            html5: true,
            src: voicePath,
            onplay: () => {
                this.activeTrack = voicePath;
                this.isPlaying = true;
            },
            onend: () => { },
        });
        this.player.play();
    }
    ngOnDestroy() {
        if (this.player) {
            this.player.stop();
        }
    }
};
PuzzleSoundComponent.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["ModalController"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["NavParams"] },
    { type: src_app_auth_auth_service__WEBPACK_IMPORTED_MODULE_6__["AuthService"] }
];
PuzzleSoundComponent = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
        selector: 'app-puzzle-sound',
        template: _raw_loader_puzzle_sound_component_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_puzzle_sound_component_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
    })
], PuzzleSoundComponent);



/***/ }),

/***/ "lz/e":
/*!**********************************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/training/puzzle-image/puzzle-sound/puzzle-sound.component.html ***!
  \**********************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<!-- <div  class=\"sound-popup\">\r\n<div class=\"sound\" *ngIf=\"voicePath\">\r\n  <div class=\"sound-bg\">\r\n    <div class=\"img-volume\">\r\n      <ion-img\r\n      class=\"animate__animated animate__jello animate__delay-2s animate__bounce animate__infinite\"\r\n      (click)=\"startAudio(voicePath)\" src=\"../../../assets/icon/Vector.png\">\r\n    </ion-img>\r\n    </div>\r\n  </div>\r\n  <img class=\"danish-flag\" [src]=\"userInfo.languageIcon\" alt=\"\" />\r\n</div>\r\n<div class=\"sound\" *ngIf=\"voicePathDanish\">\r\n  <div class=\"sound-bg\">\r\n    <div class=\"img-volume\">\r\n      <ion-img\r\n      class=\"animate__animated animate__jello animate__delay-2s animate__bounce animate__infinite\"\r\n      (click)=\"startAudio(voicePathDanish)\" src=\"../../../assets/icon/Vector.png\">\r\n    </ion-img>\r\n    </div>\r\n  </div>\r\n  <img class=\"danish-flag\" src=\"../../../assets/icon/da.png\" alt=\"\" />\r\n</div>\r\n</div> -->\r\n\r\n\r\n<ion-grid>\r\n  <ion-row>\r\n    <ion-col size=\"12\">\r\n      <ion-img class=\"image-question\" loading=\"lazy\" [src]=\"imagePath\"></ion-img>\r\n    </ion-col>\r\n  </ion-row>\r\n</ion-grid>\r\n");

/***/ }),

/***/ "szV/":
/*!************************************************************!*\
  !*** ./src/app/training/puzzle-image/puzzle-image.page.ts ***!
  \************************************************************/
/*! exports provided: PuzzleImagePage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PuzzleImagePage", function() { return PuzzleImagePage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _raw_loader_puzzle_image_page_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! raw-loader!./puzzle-image.page.html */ "NecZ");
/* harmony import */ var _puzzle_image_page_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./puzzle-image.page.scss */ "cmRR");
/* harmony import */ var _puzzle_sound_puzzle_sound_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./puzzle-sound/puzzle-sound.component */ "idoe");
/* harmony import */ var _shared_models_puzzleImageTranslation__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./../../shared/models/puzzleImageTranslation */ "yFRR");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ "8Y7J");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/router */ "iInd");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ionic/angular */ "sZkV");
/* harmony import */ var src_app_shared_services_storage_service__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! src/app/shared/services/storage.service */ "fbMX");
/* harmony import */ var _angular_cdk_drag_drop__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/cdk/drag-drop */ "ltgo");
/* harmony import */ var src_app_shared_services_exercise_service__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! src/app/shared/services/exercise.service */ "4YRF");
/* harmony import */ var howler__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! howler */ "HlzF");
/* harmony import */ var howler__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(howler__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var _help_modal_help_modal_component__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ../help-modal/help-modal.component */ "kxUF");













let PuzzleImagePage = class PuzzleImagePage {
    constructor(storageService, route, router, toastController, navController, exerciseService, popoverController, modalController) {
        this.storageService = storageService;
        this.route = route;
        this.router = router;
        this.toastController = toastController;
        this.navController = navController;
        this.exerciseService = exerciseService;
        this.popoverController = popoverController;
        this.modalController = modalController;
        this.questionsArray = [];
        this.answersArray = [];
        this.nextButton = false;
        this.lengthQuestion = 0;
        //howler
        this.player = null;
        this.isPlaying = false;
        this.subs = [];
        this.isLoading = false;
        this.limit = 1;
        this.currentIndex = 0;
        this.audio = new Audio('../../../assets/iphone_ding.mp3');
        this.slideOpts = {
            initialSlide: 0,
            speed: 400,
            slidesPerView: 1,
            scrollbar: true,
            loop: false,
            noSwipingClass: 'swiper-no-swiping',
        };
    }
    ngOnInit() {
        this.userInfo = this.storageService.getUser();
        // ** get courseId And exerciseId
        this.courseId = +this.route.snapshot.paramMap.get('courseId');
        this.exerciseType = +this.route.snapshot.paramMap.get('exerciseId');
        this.getQuestionAndAnswer();
    }
    // ** get question and answer puzzle text
    getQuestionAndAnswer() {
        this.isLoading = true;
        this.questionsArray = [];
        this.answersArray = [];
        this.subs.push(this.exerciseService
            .getCourseExercise(this.exerciseType, this.courseId, this.currentIndex, this.limit)
            .subscribe((response) => {
            console.log(response);
            this.questionAndAnswerItems = response;
            this.lengthQuestion = response['length'];
            if (this.lengthQuestion == 0) {
                this.errorMessage("There are no available questions in this exercise");
                setTimeout(() => {
                    this.navController.navigateRoot(['/exercise', { courseId: this.courseId }]);
                }, 100);
            }
            this.isLoading = false;
            //Questions
            for (let index = 0; index < this.questionAndAnswerItems.puzzleImages.length; index++) {
                let arr = [];
                let qpz = new _shared_models_puzzleImageTranslation__WEBPACK_IMPORTED_MODULE_4__["PuzzleImageTranslations"]();
                qpz.id = this.questionAndAnswerItems.puzzleImages[index].id;
                qpz.imagePath =
                    this.questionAndAnswerItems.puzzleImages[index].imagePath;
                qpz.guidId =
                    this.questionAndAnswerItems.puzzleImages[index].imageGuidId;
                qpz.type = 'question';
                qpz.voicePath = null;
                qpz.voicePathDanish = null;
                qpz.keyword = null;
                qpz.disabled = true;
                arr.push(qpz);
                this.questionsArray.push(arr);
            }
            //Answers
            for (let index = 0; index < this.questionAndAnswerItems.puzzleImagesTranslation.length; index++) {
                let arr = [];
                let apz = new _shared_models_puzzleImageTranslation__WEBPACK_IMPORTED_MODULE_4__["PuzzleImageTranslations"]();
                apz.id =
                    this.questionAndAnswerItems.puzzleImagesTranslation[index].id;
                apz.keywordId =
                    this.questionAndAnswerItems.puzzleImagesTranslation[index].keywordId;
                apz.keyword =
                    this.questionAndAnswerItems.puzzleImagesTranslation[index].keyword;
                apz.guidId =
                    this.questionAndAnswerItems.puzzleImagesTranslation[index].imageGuidId;
                apz.type = 'answer';
                apz.disabled = false;
                apz.voicePath =
                    this.questionAndAnswerItems.puzzleImagesTranslation[index].voicePath;
                apz.voicePathDanish =
                    this.questionAndAnswerItems.puzzleImagesTranslation[index].voicePathDanish;
                this.answersArray.push(apz);
            }
        }));
    }
    // ** Get Current Index
    getCurrentIndex() {
        this.slides
            .getActiveIndex()
            .then((current) => (this.currentIndex = current));
    }
    // ** Drop Function
    drop(event) {
        if (this.player) {
            this.player.stop();
        }
        var prevData = event.previousContainer.data;
        var data = event.container.data;
        var prevIndex = event.previousIndex;
        var currIndex = event.currentIndex;
        if (event.previousContainer === event.container) {
            console.log("same");
            Object(_angular_cdk_drag_drop__WEBPACK_IMPORTED_MODULE_9__["moveItemInArray"])(data, prevIndex, this.currentIndex);
        }
        else {
            if (event.container.data.length == 1) {
                Object(_angular_cdk_drag_drop__WEBPACK_IMPORTED_MODULE_9__["transferArrayItem"])(prevData, data, prevIndex, 1);
            }
            else {
                if (data[0].type == "question" && prevData[0].type == "question") {
                    Object(_angular_cdk_drag_drop__WEBPACK_IMPORTED_MODULE_9__["transferArrayItem"])(prevData, data, 1, 2);
                    Object(_angular_cdk_drag_drop__WEBPACK_IMPORTED_MODULE_9__["transferArrayItem"])(data, prevData, 1, 1);
                }
            }
        }
        if (this.answersArray.length === 0) {
            this.nextButton = true;
        }
        else {
            this.nextButton = false;
        }
    }
    // ** Move to Next slide
    slideNext() {
        // ** get check
        let arrayPuzzle = [];
        this.questionsArray.forEach((values) => {
            console.log('values', values);
            arrayPuzzle.push({
                puzzleWithImageQuestionId: values[0].id,
                imageGuid: values[0].guidId,
                wordId: values[1].keywordId,
            });
        });
        this.exerciseService
            .checkAnswerPuzzleWithImage(arrayPuzzle)
            .subscribe((response) => {
            console.log(response);
            const isCorrect = response['result'].isCorrect;
            if (isCorrect === true) {
                this.successMessage('Thanks the answer is correct');
                if (this.player) {
                    this.player.stop();
                }
                this.currentIndex += 1;
                this.getQuestionAndAnswer();
                this.slides.slideNext();
                if (this.currentIndex === this.lengthQuestion) {
                    this.successMessage('Thanks for resolving questions');
                    setTimeout(() => {
                        this.navController.navigateRoot([
                            '/exercise',
                            { courseId: this.courseId },
                        ]);
                    }, 100);
                }
            }
            else if (isCorrect === false) {
                this.errorMessage('The answer is wrong and please choose correct answer');
            }
        });
    }
    successMessage(msg) {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            this.audio.load();
            this.audio.play();
            const toast = yield this.toastController.create({
                message: msg,
                duration: 3000,
                cssClass: 'ion-success',
                color: 'success',
            });
            toast.present();
        });
    }
    errorMessage(msg) {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            this.audio.load();
            this.audio.play();
            const toast = yield this.toastController.create({
                message: msg,
                duration: 3000,
                cssClass: 'ion-error',
                color: 'danger',
            });
            toast.present();
        });
    }
    presentPopover(ev, item) {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            const popover = yield this.popoverController.create({
                component: _puzzle_sound_puzzle_sound_component__WEBPACK_IMPORTED_MODULE_3__["PuzzleSoundComponent"],
                componentProps: {
                    voicePath: item.voicePath,
                    voicePathDanish: item.voicePathDanish,
                    imagePath: item.imagePath,
                },
                cssClass: 'my-custom-class',
                event: ev,
                translucent: true,
            });
            yield popover.present();
        });
    }
    startAudio(voicePath) {
        if (this.player) {
            this.player.stop();
        }
        this.player = new howler__WEBPACK_IMPORTED_MODULE_11__["Howl"]({
            html5: true,
            src: voicePath,
            onplay: () => {
                this.activeTrack = voicePath;
                this.isPlaying = true;
            },
            onend: () => { },
        });
        this.player.play();
    }
    presentModal() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            const modal = yield this.modalController.create({
                component: _help_modal_help_modal_component__WEBPACK_IMPORTED_MODULE_12__["HelpModalComponent"],
                componentProps: {
                    "modalLink": "https://khrs-admin.sdex.online/assets/tutorials/single_choice_tutorial.mp4",
                    "modalTitle": "Puzzle Wiith Image Tutorial"
                }
            });
            return yield modal.present();
        });
    }
    slidePrev() {
        this.currentIndex -= 1;
        this.getQuestionAndAnswer();
        this.slides.slidePrev();
    }
    ngOnDestroy() {
        this.subs.forEach((sub) => {
            sub.unsubscribe();
        });
        if (this.player) {
            this.player.stop();
        }
    }
};
PuzzleImagePage.ctorParameters = () => [
    { type: src_app_shared_services_storage_service__WEBPACK_IMPORTED_MODULE_8__["StorageService"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_6__["ActivatedRoute"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_6__["Router"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_7__["ToastController"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_7__["NavController"] },
    { type: src_app_shared_services_exercise_service__WEBPACK_IMPORTED_MODULE_10__["ExerciseService"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_7__["PopoverController"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_7__["ModalController"] }
];
PuzzleImagePage.propDecorators = {
    slides: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_5__["ViewChild"], args: ['slides',] }],
    image: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_5__["ViewChild"], args: ['image',] }]
};
PuzzleImagePage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_5__["Component"])({
        selector: 'app-puzzle-image',
        template: _raw_loader_puzzle_image_page_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_puzzle_image_page_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
    })
], PuzzleImagePage);



/***/ })

}]);
//# sourceMappingURL=puzzle-image-puzzle-image-module.js.map